"""
integracion_views.py — Vistas para integración numérica.
Trapecio, Simpson, Punto Medio.
"""
from PyQt6.QtWidgets import QWidget, QFormLayout, QLineEdit, QLabel, QComboBox
from ui.views.base_method_view import BaseMethodView
from ui.components.math_input import MathInput
from ui.styles.theme import ThemeManager
from core.integracion_derivacion.integracion_derivacion import (
    punto_medio, trapecio, simpson, diferencias_finitas,
)


class PuntoMedioView(BaseMethodView):

    def _get_method_name(self) -> str:
        return "Regla del Punto Medio"

    def _get_module_name(self) -> str:
        return "Integración Numérica"

    def _get_method_description(self) -> str:
        return ("Aproxima el área bajo la curva calculando rectángulos cuya altura "
                "está dada por la función evaluada en el centro de cada subintervalo.")

    def _build_form(self) -> QWidget:
        widget = QWidget()
        layout = QFormLayout(widget)
        layout.setSpacing(10)

        self._input_func = MathInput()
        self._input_func.setPlaceholderText("Ej: x^2")

        self._input_a = QLineEdit()
        self._input_a.setPlaceholderText("Ej: 0.0")

        self._input_b = QLineEdit()
        self._input_b.setPlaceholderText("Ej: 1.0")

        self._input_n = QLineEdit("10")
        self._input_n.setToolTip("Número de rectángulos")

        layout.addRow("f(x) =", self._input_func)
        layout.addRow("a (límite inferior):", self._input_a)
        layout.addRow("b (límite superior):", self._input_b)
        layout.addRow("n (rectángulos):", self._input_n)

        return widget

    def _get_parameters(self) -> dict:
        return {
            "f(x)": self._input_func.text(),
            "a": self._input_a.text(),
            "b": self._input_b.text(),
            "n": self._input_n.text(),
        }

    def _run_calculation(self) -> dict:
        result = punto_medio(
            func_str=self._input_func.text().strip(),
            a=float(self._input_a.text()),
            b=float(self._input_b.text()),
            n_intervals=int(self._input_n.text()),
        )
        headers = ["No.", "Xi", "Xi + 1", "X̄", "f(X̄)", "Area (Ai)"]
        rows = [[r.index, r.xi, r.xi_plus_1, r.x_mid, r.f_x_mid, r.area_i] for r in result.table]

        return {
            "message": result.message, "converged": True,
            "procedure_steps": result.procedure_steps,
            "table_headers": headers, "table_rows": rows,
            "x_plot": result.x_plot, "y_plot": result.y_plot,
            "xlabel": "x", "ylabel": "f(x)", "plot_label": "f(x)",
            "rectangles": result.rectangles
        }

    def _display_result(self, result: dict):
        super()._display_result(result)
        
        # Inyectar rectángulos de área (VECTORIZADO)
        colors = ThemeManager.colors().PLOT_LINE_COLORS
        rect_color = colors[1] if len(colors) > 1 else "blue"
        
        rects = result.get("rectangles", [])
        if rects:
            x_mids = [r["x_mid"] for r in rects]
            heights = [r["height"] for r in rects]
            width = rects[0]["width"]
            
            # Dibujar en bloque todos los rectángulos de forma nativa e instantánea
            self._plot_widget.axes.bar(
                x_mids, heights, width=width, align="center",
                edgecolor="black", color=rect_color, alpha=0.3, zorder=2
            )
            # Dibujar el centro de todos ellos
            self._plot_widget.axes.scatter(
                x_mids, heights, color="red", zorder=4, s=30, marker="o"
            )
            
        self._plot_widget.refresh()

    def _get_examples(self) -> list[dict]:
        return [
            {
                "name": "1. f(x) = x²  [0, 1] (Simple)",
                "values": {"func": "x^2", "a": "0", "b": "1", "n": "10"}
            },
            {
                "name": "2. f(x) = sin(x)  [0, 3.14159] (Trigonométrica)",
                "values": {"func": "sin(x)", "a": "0", "b": "3.14159", "n": "6"}
            },
            {
                "name": "3. f(x) = e^x  [0, 2] (Exponencial)",
                "values": {"func": "e^x", "a": "0", "b": "2", "n": "8"}
            },
            {
                "name": "4. f(x) = 1/x  [1, 2] (Logarítmica)",
                "values": {"func": "1/x", "a": "1", "b": "2", "n": "12"}
            }
        ]

    def _load_example(self):
        self._input_func.setText("x^2")
        self._input_a.setText("0")
        self._input_b.setText("1")
        self._input_n.setText("10")

    def _clear_form(self):
        self._input_func.clear()
        self._input_a.clear()
        self._input_b.clear()
        self._input_n.setText("10")


class TrapecioView(BaseMethodView):

    def _get_method_name(self) -> str:
        return "Regla del Trapecio"

    def _get_module_name(self) -> str:
        return "Integración Numérica"

    def _get_method_description(self) -> str:
        return ("Aproxima la integral definida ∫f(x)dx dividiendo el intervalo "
                "en trapecios y sumando sus áreas.")

    def _build_form(self) -> QWidget:
        widget = QWidget()
        layout = QFormLayout(widget)
        layout.setSpacing(10)

        self._input_func = MathInput()
        self._input_func.setPlaceholderText("Ej: x^2")

        self._input_a = QLineEdit()
        self._input_a.setPlaceholderText("Ej: 0")

        self._input_b = QLineEdit()
        self._input_b.setPlaceholderText("Ej: 1")

        self._input_n = QLineEdit("10")
        self._input_n.setToolTip("Número de subintervalos")

        layout.addRow("f(x) =", self._input_func)
        layout.addRow("a (límite inferior):", self._input_a)
        layout.addRow("b (límite superior):", self._input_b)
        layout.addRow("n (subintervalos):", self._input_n)

        return widget

    def _get_parameters(self) -> dict:
        return {
            "f(x)": self._input_func.text(),
            "a": self._input_a.text(),
            "b": self._input_b.text(),
            "n": self._input_n.text(),
        }

    def _run_calculation(self) -> dict:
        result = trapecio(
            func_str=self._input_func.text().strip(),
            a=float(self._input_a.text()),
            b=float(self._input_b.text()),
            n_intervals=int(self._input_n.text()),
        )
        headers = ["No.", "dx", "xi", "f(xi)", "Factor", "dx/2 * factor * f(xi)"]
        rows = [[r.index, r.dx, r.xi, r.fxi, r.factor, r.partial] for r in result.table]

        return {
            "message": result.message, "converged": True,
            "procedure_steps": result.procedure_steps,
            "table_headers": headers, "table_rows": rows,
            "x_plot": result.x_plot, "y_plot": result.y_plot,
            "xlabel": "x", "ylabel": "f(x)", "plot_label": "f(x)",
        }

    def _display_result(self, result: dict):
        super()._display_result(result)
        
        colors = ThemeManager.colors().PLOT_LINE_COLORS
        poly_color = colors[1] if len(colors) > 1 else "blue"
        
        rows = result.get("table_rows", [])
        if rows and len(rows) > 0 and len(rows[0]) > 3:
            # row[2] = xi, row[3] = f(xi)
            x_points = [r[2] for r in rows]
            y_points = [r[3] for r in rows]
            
            # Área de Trapecios
            self._plot_widget.axes.fill_between(
                x_points, 0, y_points,
                edgecolor="black", color=poly_color, alpha=0.3, zorder=2
            )
            # Puntos extremos evaluados
            self._plot_widget.axes.plot(
                x_points, y_points, 'ro', zorder=4, markersize=5
            )
            
        self._plot_widget.refresh()

    def _get_examples(self) -> list[dict]:
        return [
            {
                "name": "1. f(x) = x²  [0, 1] (Polinomial)",
                "values": {"func": "x^2", "a": "0", "b": "1", "n": "10"}
            },
            {
                "name": "2. f(x) = 3x³ - 2x  [1, 3] (Cúbica)",
                "values": {"func": "3*x^3 - 2*x", "a": "1", "b": "3", "n": "8"}
            },
            {
                "name": "3. f(x) = cos(x)  [0, 1.5708] (Trigonométrica)",
                "values": {"func": "cos(x)", "a": "0", "b": "1.5708", "n": "10"}
            },
            {
                "name": "4. f(x) = 1/(1+x²)  [0, 1] (Racional)",
                "values": {"func": "1/(1+x^2)", "a": "0", "b": "1", "n": "10"}
            }
        ]

    def _load_example(self):
        self._input_func.setText("x^2")
        self._input_a.setText("0")
        self._input_b.setText("1")
        self._input_n.setText("10")

    def _clear_form(self):
        self._input_func.clear()
        self._input_a.clear()
        self._input_b.clear()
        self._input_n.setText("10")


class SimpsonView(BaseMethodView):

    def _get_method_name(self) -> str:
        return "Regla de Simpson 1/3"

    def _get_module_name(self) -> str:
        return "Integración Numérica"

    def _get_method_description(self) -> str:
        return ("Aproxima la integral definida usando parábolas. "
                "Requiere un número par de subintervalos.")

    def _build_form(self) -> QWidget:
        widget = QWidget()
        layout = QFormLayout(widget)
        layout.setSpacing(10)

        self._input_func = MathInput()
        self._input_func.setPlaceholderText("Ej: x^2")

        self._input_a = QLineEdit()
        self._input_a.setPlaceholderText("Ej: 0")

        self._input_b = QLineEdit()
        self._input_b.setPlaceholderText("Ej: 1")

        self._input_n = QLineEdit("10")
        self._input_n.setToolTip("Número de subintervalos (debe ser par)")

        layout.addRow("f(x) =", self._input_func)
        layout.addRow("a (límite inferior):", self._input_a)
        layout.addRow("b (límite superior):", self._input_b)
        layout.addRow("n (subintervalos, par):", self._input_n)

        return widget

    def _get_parameters(self) -> dict:
        return {
            "f(x)": self._input_func.text(),
            "a": self._input_a.text(),
            "b": self._input_b.text(),
            "n": self._input_n.text(),
        }

    def _run_calculation(self) -> dict:
        result = simpson(
            func_str=self._input_func.text().strip(),
            a=float(self._input_a.text()),
            b=float(self._input_b.text()),
            n_intervals=int(self._input_n.text()),
        )
        headers = ["No.", "dx", "xi", "f(xi)", "Factor", "(dx/3) * factor * f(xi)"]
        rows = [[r.index, r.dx, r.xi, r.fxi, r.factor, r.partial] for r in result.table]

        return {
            "message": result.message, "converged": True,
            "procedure_steps": result.procedure_steps,
            "table_headers": headers, "table_rows": rows,
            "x_plot": result.x_plot, "y_plot": result.y_plot,
            "xlabel": "x", "ylabel": "f(x)", "plot_label": "f(x)",
            "parabolas": getattr(result, "parabolas", [])
        }

    def _display_result(self, result: dict):
        super()._display_result(result)

        colors = ThemeManager.colors().PLOT_LINE_COLORS
        poly_color = colors[1] if len(colors) > 1 else "blue"

        for p in result.get("parabolas", []):
            px, py = p["x"], p["y"]
            
            # Área bajo la parábola de Simpson
            self._plot_widget.axes.fill_between(
                px, 0, py,
                edgecolor="black", color=poly_color, alpha=0.3, zorder=2
            )
            
            # Demarcación de los 3 puntos base por cada intervalo doble
            if len(px) >= 3:
                mid = len(px) // 2
                self._plot_widget.axes.plot(
                    [px[0], px[mid], px[-1]],
                    [py[0], py[mid], py[-1]],
                    'ro', zorder=4, markersize=5
                )

        self._plot_widget.refresh()

    def _get_examples(self) -> list[dict]:
        return [
            {
                "name": "1. f(x) = x²  [0, 1] (Simple)",
                "values": {"func": "x^2", "a": "0", "b": "1", "n": "10"}
            },
            {
                "name": "2. f(x) = x⁴  [0, 2] (Grado 4)",
                "values": {"func": "x^4", "a": "0", "b": "2", "n": "4"}
            },
            {
                "name": "3. f(x) = sqrt(x)  [1, 4] (Raíz)",
                "values": {"func": "sqrt(x)", "a": "1", "b": "4", "n": "6"}
            },
            {
                "name": "4. f(x) = 1/x  [1, 3] (Hiperbólica)",
                "values": {"func": "1/x", "a": "1", "b": "3", "n": "8"}
            }
        ]

    def _load_example(self):
        self._input_func.setText("x^2")
        self._input_a.setText("0")
        self._input_b.setText("1")
        self._input_n.setText("10")

    def _clear_form(self):
        self._input_func.clear()
        self._input_a.clear()
        self._input_b.clear()
        self._input_n.setText("10")


class DiferenciasFinitasView(BaseMethodView):

    def _get_method_name(self) -> str:
        return "Diferencias Finitas (Derivación)"

    def _get_module_name(self) -> str:
        return "Integración y Derivación"

    def _get_method_description(self) -> str:
        return ("Aproxima el valor de la derivada (1ra o 2da) de una función en un punto x₀ "
                "usando esquemas de diferencias hacia adelante, hacia atrás o centrales.")

    def _build_form(self) -> QWidget:
        widget = QWidget()
        layout = QFormLayout(widget)
        layout.setSpacing(10)

        self._input_func = MathInput()
        self._input_func.setPlaceholderText("Ej: x^2")

        self._input_x0 = QLineEdit()
        self._input_x0.setPlaceholderText("Ej: 2.0")

        self._input_h = QLineEdit("0.1")
        self._input_h.setToolTip("Paso de diferenciación h")

        self._combo_order = QComboBox()
        self._combo_order.addItems(["Primera Derivada", "Segunda Derivada"])

        self._combo_dir = QComboBox()
        self._combo_dir.addItems(["Central", "Hacia adelante", "Hacia atrás"])

        layout.addRow("f(x) =", self._input_func)
        layout.addRow("x₀ (evaluación):", self._input_x0)
        layout.addRow("h (paso):", self._input_h)
        layout.addRow("Orden:", self._combo_order)
        layout.addRow("Dirección:", self._combo_dir)

        return widget

    def _get_parameters(self) -> dict:
        return {
            "f(x)": self._input_func.text(),
            "x0": self._input_x0.text(),
            "h": self._input_h.text(),
            "Orden": self._combo_order.currentText(),
            "Dirección": self._combo_dir.currentText(),
        }

    def _run_calculation(self) -> dict:
        # Validar campos
        func_text = self._input_func.text().strip()
        if not func_text:
            raise ValueError("Por favor, ingrese la función f(x).")

        x0_text = self._input_x0.text().strip()
        if not x0_text:
            raise ValueError("Por favor, ingrese el punto de evaluación x₀.")
        try:
            x0 = float(x0_text)
        except ValueError as e:
            raise ValueError("El punto de evaluación x₀ debe ser un número real válido.") from e

        h_text = self._input_h.text().strip()
        if not h_text:
            raise ValueError("Por favor, ingrese el paso h.")
        try:
            h = float(h_text)
            if h <= 0:
                raise ValueError("El paso h debe ser positivo y mayor que cero.")
        except ValueError as e:
            if "positivo" in str(e): raise
            raise ValueError("El paso h debe ser un número real válido (ej: 0.1).") from e

        # Determinar orden
        order_idx = self._combo_order.currentIndex()
        order = 1 if order_idx == 0 else 2

        # Determinar dirección
        dir_text = self._combo_dir.currentText().strip()
        if dir_text == "Hacia adelante":
            direction = "adelante"
        elif dir_text == "Hacia atrás":
            direction = "atrás"
        else:
            direction = "central"

        result = diferencias_finitas(
            func_str=func_text, x0=x0, h=h, order=order, direction=direction
        )

        headers = ["Nodo", "x", "f(x)"]
        rows = [[r.node, r.x, r.fx] for r in result.table]

        return {
            "message": result.message, "converged": True,
            "procedure_steps": result.procedure_steps,
            "table_headers": headers, "table_rows": rows,
            "x_plot": result.x_plot, "y_plot": result.y_plot,
            "xlabel": "x", "ylabel": "f(x)", "plot_label": "f(x)",
            "x_tangent": result.x_tangent, "y_tangent": result.y_tangent,
        }

    def _display_result(self, result: dict):
        super()._display_result(result)

        # Graficar recta tangente (si existe)
        x_tangent = result.get("x_tangent")
        y_tangent = result.get("y_tangent")

        if x_tangent and y_tangent:
            colors = ThemeManager.colors().PLOT_LINE_COLORS
            tangent_color = colors[1] if len(colors) > 1 else "blue"

            self._plot_widget.axes.plot(
                x_tangent, y_tangent, "--", color=tangent_color,
                label="Aprox. Recta Tangente", linewidth=1.5
            )

        # Graficar los nodos evaluados como puntos destacados
        rows = result.get("table_rows", [])
        if rows:
            x_nodes = [r[1] for r in rows]
            y_nodes = [r[2] for r in rows]

            self._plot_widget.axes.scatter(
                x_nodes, y_nodes, color="red", zorder=5, s=50, label="Nodos evaluados"
            )

        self._plot_widget.axes.legend()
        self._plot_widget.refresh()

    def _get_examples(self) -> list[dict]:
        return [
            {
                "name": "1. x² en x₀=2 (Derivada 1, Central)",
                "values": {"func": "x^2", "x0": "2.0", "h": "0.1", "order_idx": 0, "dir_idx": 0}
            },
            {
                "name": "2. sin(x) en x₀=0 (Derivada 1, Adelante)",
                "values": {"func": "sin(x)", "x0": "0.0", "h": "0.05", "order_idx": 0, "dir_idx": 1}
            },
            {
                "name": "3. e^x en x₀=1 (Derivada 2, Central)",
                "values": {"func": "e^x", "x0": "1.0", "h": "0.1", "order_idx": 1, "dir_idx": 0}
            },
            {
                "name": "4. x³ - 2x en x₀=1.5 (Derivada 1, Atrás)",
                "values": {"func": "x^3 - 2*x", "x0": "1.5", "h": "0.1", "order_idx": 0, "dir_idx": 2}
            }
        ]

    def _load_example(self):
        self._input_func.setText("x^2")
        self._input_x0.setText("2.0")
        self._input_h.setText("0.1")
        self._combo_order.setCurrentIndex(0)
        self._combo_dir.setCurrentIndex(0)

    def _clear_form(self):
        self._input_func.clear()
        self._input_x0.clear()
        self._input_h.setText("0.1")
        self._combo_order.setCurrentIndex(0)
        self._combo_dir.setCurrentIndex(0)
