"""
interpolacion_views.py — Vistas para interpolación (Lagrange, Newton).
"""
from PyQt6.QtWidgets import QWidget, QFormLayout, QLineEdit, QLabel
from ui.views.base_method_view import BaseMethodView
from ui.components.math_input import MathInput
from core.interpolacion.interpolacion import lagrange, newton_interpolation


class LagrangeView(BaseMethodView):

    def _get_method_name(self) -> str:
        return "Interpolación de Lagrange"

    def _get_module_name(self) -> str:
        return "Interpolación"

    def _get_method_description(self) -> str:
        return ("Construye un polinomio interpolante a partir de un conjunto "
                "de puntos conocidos (xi, yi) usando los polinomios base de Lagrange.")

    def _build_form(self) -> QWidget:
        widget = QWidget()
        layout = QFormLayout(widget)
        layout.setSpacing(10)

        self._input_x = MathInput()
        self._input_x.setPlaceholderText("Ej: 1, 2, 3, 4")
        self._input_x.setToolTip("Valores de x separados por comas")

        self._input_y = MathInput()
        self._input_y.setPlaceholderText("Ej: 1, 4, 9, 16")
        self._input_y.setToolTip("Valores de y correspondientes, separados por comas")

        self._input_xeval = MathInput()
        self._input_xeval.setPlaceholderText("Ej: 2.5 (opcional)")
        self._input_xeval.setToolTip("Valor de x donde se desea interpolar")

        layout.addRow("Valores x:", self._input_x)
        layout.addRow("Valores y:", self._input_y)
        layout.addRow("x a interpolar:", self._input_xeval)

        help_label = QLabel("💡 Ingrese los puntos separados por comas. No se permiten x repetidos.")
        help_label.setObjectName("subtitle")
        help_label.setWordWrap(True)
        layout.addRow(help_label)

        return widget

    def _get_parameters(self) -> dict:
        return {
            "Puntos x": self._input_x.text(),
            "Puntos y": self._input_y.text(),
            "x a interpolar": self._input_xeval.text(),
        }

    def _run_calculation(self) -> dict:
        x_points = [float(v.strip()) for v in self._input_x.text().split(",")]
        y_points = [float(v.strip()) for v in self._input_y.text().split(",")]
        x_eval_text = self._input_xeval.text().strip()
        x_eval = float(x_eval_text) if x_eval_text else None

        result = lagrange(x_points, y_points, x_eval)

        headers = ["i", "xi", "yi", "Li(x)", "Término", "Acumulado"]
        rows = [[r.i, r.xi, r.yi, r.li_value, r.term, r.accumulated] for r in result.table]

        return {
            "message": result.message, "converged": True,
            "polynomial_math": result.polynomial_math,
            "procedure_steps": result.procedure_steps,
            "table_headers": headers, "table_rows": rows,
            "x_plot": result.x_plot, "y_plot": result.y_plot,
            "x_points": x_points, "y_points": y_points,
            "highlight_x": x_eval,
            "highlight_label": f"P({x_eval}) ≈ {result.interpolated_value:.6f}" if x_eval is not None else None,
            "xlabel": "x", "ylabel": "P(x)", "plot_label": "Polinomio interpolante",
        }

    def _get_examples(self) -> list[dict]:
        return [
            {
                "name": "1. Cuadrática (Puntos: [1,1], [2,4], [4,16])",
                "values": {"x": "1, 2, 4", "y": "1, 4, 16", "xeval": "3"}
            },
            {
                "name": "2. Cúbica (Puntos: [0,1], [1,3], [2,2], [3,5])",
                "values": {"x": "0, 1, 2, 3", "y": "1, 3, 2, 5", "xeval": "1.5"}
            },
            {
                "name": "3. Lineal (Puntos: [0,1], [2,5])",
                "values": {"x": "0, 2", "y": "1, 5", "xeval": "1.0"}
            },
            {
                "name": "4. Curva de Runge (Puntos: [-2,0.2], [-1,0.5], [0,1], [1,0.5], [2,0.2])",
                "values": {"x": "-2, -1, 0, 1, 2", "y": "0.2, 0.5, 1.0, 0.5, 0.2", "xeval": "0.5"}
            }
        ]

    def _load_example(self):
        self._input_x.setText("1, 2, 4, 7")
        self._input_y.setText("1, 4, 16, 49")
        self._input_xeval.setText("3")

    def _clear_form(self):
        self._input_x.clear()
        self._input_y.clear()
        self._input_xeval.clear()


class NewtonInterpolacionView(BaseMethodView):

    def _get_method_name(self) -> str:
        return "Interpolación de Newton"

    def _get_module_name(self) -> str:
        return "Interpolación"

    def _get_method_description(self) -> str:
        return ("Construye un polinomio interpolante usando diferencias divididas de Newton. "
                "Eficiente para agregar nuevos puntos.")

    def _build_form(self) -> QWidget:
        widget = QWidget()
        layout = QFormLayout(widget)
        layout.setSpacing(10)

        self._input_x = MathInput()
        self._input_x.setPlaceholderText("Ej: 1, 2, 3, 4")

        self._input_y = MathInput()
        self._input_y.setPlaceholderText("Ej: 1, 4, 9, 16")

        self._input_xeval = MathInput()
        self._input_xeval.setPlaceholderText("Ej: 2.5 (opcional)")

        layout.addRow("Valores x:", self._input_x)
        layout.addRow("Valores y:", self._input_y)
        layout.addRow("x a interpolar:", self._input_xeval)

        return widget

    def _get_parameters(self) -> dict:
        return {
            "Puntos x": self._input_x.text(),
            "Puntos y": self._input_y.text(),
            "x a interpolar": self._input_xeval.text(),
        }

    def _run_calculation(self) -> dict:
        x_points = [float(v.strip()) for v in self._input_x.text().split(",")]
        y_points = [float(v.strip()) for v in self._input_y.text().split(",")]
        x_eval_text = self._input_xeval.text().strip()
        x_eval = float(x_eval_text) if x_eval_text else None

        result = newton_interpolation(x_points, y_points, x_eval)

        headers = ["i", "xi", "yi", "Dif. Dividida", "Coeficiente", "Acumulado"]
        rows = [[r.i, r.xi, r.yi, r.divided_diff, r.coefficient, r.accumulated] for r in result.table]

        return {
            "message": result.message, "converged": True,
            "polynomial_math": result.polynomial_math,
            "procedure_steps": result.procedure_steps,
            "table_headers": headers, "table_rows": rows,
            "x_plot": result.x_plot, "y_plot": result.y_plot,
            "x_points": x_points, "y_points": y_points,
            "highlight_x": x_eval,
            "highlight_label": f"P({x_eval}) ≈ {result.interpolated_value:.6f}" if x_eval is not None else None,
            "xlabel": "x", "ylabel": "P(x)", "plot_label": "Polinomio interpolante",
        }

    def _get_examples(self) -> list[dict]:
        return [
            {
                "name": "1. Cuadrática (Puntos: [1,1], [2,4], [4,16])",
                "values": {"x": "1, 2, 4", "y": "1, 4, 16", "xeval": "3"}
            },
            {
                "name": "2. Cúbica (Puntos: [0,1], [1,3], [2,7])",
                "values": {"x": "0, 1, 2", "y": "1, 3, 7", "xeval": "1.5"}
            },
            {
                "name": "3. Lineal (Puntos: [1,2], [3,8], [5,14], [7,20])",
                "values": {"x": "1, 3, 5, 7", "y": "2, 8, 14, 20", "xeval": "4"}
            },
            {
                "name": "4. Polinomial (Puntos: [-1,15], [0,8], [1,3], [2,0])",
                "values": {"x": "-1, 0, 1, 2", "y": "15, 8, 3, 0", "xeval": "0.5"}
            }
        ]

    def _load_example(self):
        self._input_x.setText("1, 2, 4, 7")
        self._input_y.setText("1, 4, 16, 49")
        self._input_xeval.setText("3")

    def _clear_form(self):
        self._input_x.clear()
        self._input_y.clear()
        self._input_xeval.clear()
